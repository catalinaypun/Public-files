# Valu Cal — Prototype Viewer

A vibe-coded UI prototype for **Valu Cal**, a B2B telecom quoting and subscription management tool built for Verizon Business sales reps.

---

## Folder Structure

```
valu-cal/
├── index.html                        ← Central prototype viewer (start here)
├── README.md
├── assets/
│   └── valu-cal.css                  ← Custom styles (non-VDS overrides only)
└── flows/
    ├── dashboard/
    │   ├── flow.json
    │   └── screens/
    │       └── 01-dashboard.html
    ├── account-settings/
    │   ├── flow.json
    │   └── screens/
    │       └── 01-account-settings.html
    └── quote-creation/
        ├── configure-bundle/
        │   ├── flow.json
        │   └── screens/
        │       └── 01-configure-bundle.html
        ├── save/
        │   ├── flow.json
        │   └── screens/
        │       └── 01-save.html
        ├── send-proposal/
        │   ├── flow.json
        │   └── screens/
        │       └── 01-send-proposal.html
        └── approval-process/
            ├── flow.json
            └── screens/
                └── 01-approval-process.html
```

---

## How to Run Locally

Screens are loaded inside iframes, so a local server is required (browser security blocks `file://` iframes).

```bash
# From the valu-cal/ directory:
npx serve .

# Then open: http://localhost:3000
```

---

## How to Add a New Flow

1. Create the folder under `flows/` (or `flows/quote-creation/` for sub-flows)
2. Add a `flow.json` following the schema below
3. Create `screens/01-screen-name.html` with your prototype content
4. Register the flow in the `FLOWS` array at the top of `index.html`

**flow.json schema:**
```json
{
  "id": "kebab-case-id",
  "title": "Human readable title",
  "category": "Quote Creation or null",
  "description": "One sentence describing what this flow does",
  "viewport": "desktop",
  "screens": [
    {
      "id": "01-screen-name",
      "title": "Screen title",
      "file": "screens/01-screen-name.html",
      "description": "What the user sees or does on this screen"
    }
  ]
}
```

**Register in index.html:**
```js
const FLOWS = [
  // ...existing flows...
  { id: "my-new-flow", path: "flows/my-new-flow/flow.json", category: null },
];
```

---

## CSS Architecture

| File | Purpose |
|------|---------|
| `https://catalinaypun.github.io/verizon-design-system/design-system.css` | Verizon Design System — loaded remotely. Transversal updates (tokens, typography, component fixes) automatically apply to all screens. |
| `assets/valu-cal.css` | Custom overrides and app-specific components **not** covered by VDS. Loaded after VDS so it can safely override. |

Every screen HTML links both stylesheets:
```html
<link rel="stylesheet" id="vds-stylesheet" href="https://catalinaypun.github.io/verizon-design-system/design-system.css" />
<link rel="stylesheet" href="../../../../assets/valu-cal.css" />
```
Adjust the relative `../` depth based on folder nesting level:
- `flows/{flow}/screens/` → `../../../assets/valu-cal.css` (3 levels up)
- `flows/quote-creation/{flow}/screens/` → `../../../../assets/valu-cal.css` (4 levels up)

---

## Naming Conventions

- Screen files: `01-screen-name.html`, `02-next-screen.html` (zero-padded, kebab-case)
- Flow IDs: kebab-case matching the folder name
- Mobile screens (future): append `-mobile` suffix, e.g. `01-dashboard-mobile.html`

---

## Viewport Convention

- All current screens are **desktop-first** (`min-width: 1024px`)
- Mobile variants use a `-mobile` suffix in the filename and set `"viewport": "mobile"` in `flow.json`
- The viewer displays a viewport badge per flow

---

## Happy Path

Click **▶ Full Happy Path** in the sidebar to automatically sequence through all flows in the registered order, simulating the end-to-end sales rep journey from Dashboard → Configure Bundle → Save → Send Proposal → Approval.
